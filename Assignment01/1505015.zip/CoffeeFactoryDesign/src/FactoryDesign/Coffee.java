package FactoryDesign;

public interface Coffee {
	void prepare();
}
